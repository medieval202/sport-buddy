const state = {
    token: localStorage.getItem("sportsBuddyToken"),
    user: null,
    activities: [],
    mine: [],
    venues: [],
    announcements: [],
    reservations: [],
    pending: [],
    users: [],
    realtimeStatus: null,
    radarSession: null,
    radarReceipt: null,
    socket: null,
    socketTimer: null,
    refreshTimer: null,
    heartbeatTimer: null,
    currentMatchActivityId: null
};

const viewMeta = {
    discover: ["DISCOVER", "发现运动", "找到与你合拍的运动搭子"],
    realtime: ["LIVE MATCHING", "实时找搭子", "在线即发即配，双向通知合适搭子"],
    radar: ["RADAR MATCHING", "雷达匹配", "8 扇区轮询扫描、Top-N 结算与候选锁定"],
    mine: ["MY SCHEDULE", "我的组队", "管理我发起和参与的运动"],
    venues: ["VENUE BOOKING", "场地预约", "查看空闲时段并锁定运动场地"],
    profile: ["MY PROFILE", "个人档案", "完善数据，提升匹配准确度"],
    "admin-review": ["ACTIVITY REVIEW", "活动审核", "审核学生提交的公开活动"],
    "admin-users": ["USER MANAGEMENT", "用户管理", "管理学生信用分与账户状态"],
    "admin-announcements": ["ANNOUNCEMENTS", "公告发布", "向在线用户实时发布通知"]
};

const skillLabels = {
    BEGINNER: "新手",
    INTERMEDIATE: "进阶",
    ADVANCED: "高手"
};

const statusLabels = {
    PENDING: "待审核",
    APPROVED: "已通过",
    REJECTED: "已驳回",
    CANCELLED: "已取消"
};

const slotLabels = {
    MORNING: "上午",
    AFTERNOON: "下午",
    EVENING: "晚上",
    WEEKEND: "周末"
};

const matchTimeLabels = {
    NOW: "现在",
    MORNING: "上午",
    AFTERNOON: "下午",
    EVENING: "晚上",
    WEEKEND: "周末"
};

document.addEventListener("DOMContentLoaded", boot);

async function boot() {
    bindEvents();
    setDefaultDates();
    if (state.token) {
        try {
            state.user = await api("/api/me");
            await openApp();
            return;
        } catch (error) {
            clearSession(false);
        }
    }
    showAuth();
}

function bindEvents() {
    document.querySelectorAll("[data-auth-tab]").forEach(button => {
        button.addEventListener("click", () => switchAuthTab(button.dataset.authTab));
    });

    document.getElementById("login-form").addEventListener("submit", login);
    document.getElementById("register-form").addEventListener("submit", register);
    document.getElementById("logout-btn").addEventListener("click", () => logout());

    document.querySelectorAll("[data-demo-user]").forEach(button => {
        button.addEventListener("click", () => {
            document.getElementById("login-username").value = button.dataset.demoUser;
            document.getElementById("login-password").value = button.dataset.demoPassword;
        });
    });

    document.querySelectorAll("[data-view]").forEach(button => {
        button.addEventListener("click", () => showView(button.dataset.view));
    });

    document.addEventListener("click", handleActionClick);
    document.querySelectorAll(".modal-backdrop").forEach(backdrop => {
        backdrop.addEventListener("click", event => {
            if (event.target === backdrop) {
                backdrop.classList.add("hidden");
            }
        });
    });

    document.getElementById("activity-form").addEventListener("submit", createActivity);
    document.getElementById("realtime-match-form").addEventListener("submit", startRealtimeMatch);
    document.getElementById("radar-form").addEventListener("submit", startRadarSession);
    document.getElementById("reservation-form").addEventListener("submit", createReservation);
    document.getElementById("profile-form").addEventListener("submit", saveProfile);
    document.getElementById("announcement-form").addEventListener("submit", publishAnnouncement);
    document.getElementById("reservation-venue").addEventListener("change", loadBusySlots);
    document.getElementById("reservation-date").addEventListener("change", loadBusySlots);

    document.getElementById("sport-filter").addEventListener("input", event => {
        const keyword = event.target.value.trim().toLowerCase();
        const filtered = state.activities.filter(activity =>
            !keyword
            || activity.sportType.toLowerCase().includes(keyword)
            || activity.title.toLowerCase().includes(keyword)
        );
        renderActivities(filtered, "activity-grid");
    });
    document.getElementById("refresh-activities").addEventListener("click", async () => {
        await loadActivities();
        renderActivities(state.activities, "activity-grid");
        toast("活动列表已刷新");
    });
}

async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (state.token) {
        headers.set("Authorization", `Bearer ${state.token}`);
    }
    if (options.body && !(options.body instanceof FormData)) {
        headers.set("Content-Type", "application/json");
    }

    const response = await fetch(path, { ...options, headers });
    if (response.status === 401 && state.token) {
        clearSession(true);
    }

    const text = await response.text();
    let data = null;
    if (text) {
        try {
            data = JSON.parse(text);
        } catch (error) {
            data = text;
        }
    }

    if (!response.ok) {
        const message = data && data.message
            ? data.message
            : `请求失败（${response.status}）`;
        const error = new Error(message);
        error.status = response.status;
        throw error;
    }
    return data;
}

function showAuth() {
    document.getElementById("auth-screen").classList.remove("hidden");
    document.getElementById("app-shell").classList.add("hidden");
}

async function openApp() {
    document.getElementById("auth-screen").classList.add("hidden");
    document.getElementById("app-shell").classList.remove("hidden");
    applyUserChrome();
    connectSocket();
    await refreshAll();
}

function applyUserChrome() {
    if (!state.user) {
        return;
    }
    const isAdmin = state.user.role === "ADMIN";
    document.querySelectorAll(".admin-only").forEach(element => {
        element.classList.toggle("hidden", !isAdmin);
    });
    document.querySelectorAll(".student-only").forEach(element => {
        element.classList.toggle("hidden", isAdmin);
    });
    document.getElementById("side-user-name").textContent = state.user.displayName;
    document.getElementById("side-user-role").textContent = isAdmin ? "系统管理员" : "学生用户";
    document.getElementById("side-avatar").textContent = isAdmin ? "管" : state.user.displayName.slice(0, 1);
    document.getElementById("top-credit").textContent = state.user.creditScore;
    document.getElementById("profile-credit").textContent = state.user.creditScore;
}

async function refreshAll() {
    const requests = [
        api("/api/activities"),
        api("/api/activities/mine"),
        api("/api/venues"),
        api("/api/announcements"),
        api("/api/reservations/mine")
    ];
    if (state.user.role === "STUDENT") {
        requests.push(api("/api/realtime/status"));
    }
    if (state.user.role === "ADMIN") {
        requests.push(api("/api/admin/activities/pending"));
        requests.push(api("/api/admin/users"));
    }

    try {
        const results = await Promise.all(requests);
        state.activities = results[0];
        state.mine = results[1];
        state.venues = results[2];
        state.announcements = results[3];
        state.reservations = results[4];
        if (state.user.role === "STUDENT") {
            state.realtimeStatus = results[5];
        }
        if (state.user.role === "ADMIN") {
            state.pending = results[5];
            state.users = results[6];
        }
        renderAll();
    } catch (error) {
        toast(error.message, true);
    }
}

function renderAll() {
    renderActivities(state.activities, "activity-grid");
    renderActivities(state.mine, "mine-grid");
    renderAnnouncements();
    renderVenues();
    renderReservations();
    renderRealtime();
    renderProfile();
    renderPending();
    renderUsers();
    renderAdminAnnouncements();
    document.getElementById("pending-badge").textContent = state.pending.length;
}

function renderActivities(activities, containerId) {
    const container = document.getElementById(containerId);
    if (!activities.length) {
        container.innerHTML = `
            <div class="empty-state">
                暂无运动活动。点击“发起运动”，提交你的第一场组队吧。
            </div>`;
        return;
    }

    container.innerHTML = activities.map(activity => {
        const ratio = activity.maxParticipants
            ? Math.min(100, activity.participantCount / activity.maxParticipants * 100)
            : 0;
        let statusChip = "";
        if (activity.status === "PENDING") {
            statusChip = `<span class="status-chip pending">待审核</span>`;
        } else if (activity.status === "REJECTED") {
            statusChip = `<span class="status-chip rejected">已驳回</span>`;
        } else if (activity.joined) {
            statusChip = `<span class="status-chip joined">已加入</span>`;
        }

        const isFull = activity.participantCount >= activity.maxParticipants;
        let primaryAction = "";
        if (activity.status === "APPROVED") {
            primaryAction = activity.owned
                ? `<button class="btn btn-ghost" disabled>我发起的</button>`
                : activity.joined
                ? `<button class="btn btn-ghost" data-action="leave" data-id="${activity.id}">退出</button>`
                : `<button class="btn btn-primary" data-action="join" data-id="${activity.id}" ${isFull ? "disabled" : ""}>
                    ${isFull ? "人数已满" : "加入活动"}
                   </button>`;
        } else if (activity.status === "PENDING") {
            primaryAction = `<button class="btn btn-ghost" disabled>等待审核</button>`;
        } else {
            primaryAction = `<button class="btn btn-ghost" disabled>不可加入</button>`;
        }

        const matchButton = activity.status === "APPROVED"
            ? `<button class="btn btn-outline" data-action="match" data-id="${activity.id}">AI 匹配</button>`
            : "";

        return `
            <article class="activity-card">
                <div class="card-top">
                    <span class="sport-chip">${escapeHtml(activity.sportType)}</span>
                    ${statusChip}
                </div>
                <h3>${escapeHtml(activity.title)}</h3>
                <p>${escapeHtml(activity.description || "发起人暂未填写活动说明。")}</p>
                ${activity.status === "REJECTED" && activity.rejectReason
                    ? `<div class="announcement-card"><p>驳回原因：${escapeHtml(activity.rejectReason)}</p></div>`
                    : ""}
                <div class="meta-list">
                    <span>时间 <strong>${formatDateTime(activity.startTime)}</strong></span>
                    <span>地点 <strong>${escapeHtml(activity.locationName)}</strong></span>
                    <span>发起 <strong>${escapeHtml(activity.creatorName)}</strong></span>
                    <span>门槛 <strong>${skillLabels[activity.requiredSkillLevel]} · 信用 ${activity.minCreditScore}+</strong></span>
                </div>
                <div class="progress-line"><i style="width:${ratio}%"></i></div>
                <div class="meta-list" style="border:0;padding:0;margin:0 0 13px">
                    <span>组队进度 <strong>${activity.participantCount}/${activity.maxParticipants} 人</strong></span>
                </div>
                <div class="card-actions">
                    ${matchButton}
                    ${primaryAction}
                </div>
            </article>`;
    }).join("");
}

function renderAnnouncements() {
    const container = document.getElementById("announcement-list");
    if (!state.announcements.length) {
        container.innerHTML = `<div class="empty-state">暂无校园公告</div>`;
        return;
    }
    container.innerHTML = state.announcements.slice(0, 4).map(item => `
        <article class="announcement-card">
            <strong>${escapeHtml(item.title)}</strong>
            <p>${escapeHtml(item.content)}</p>
        </article>
    `).join("");

    document.getElementById("admin-announcement-list").innerHTML =
        state.announcements.map(item => `
            <article class="admin-announcement-item">
                <strong>${escapeHtml(item.title)}</strong>
                <p>${escapeHtml(item.content)}</p>
                <small>${escapeHtml(item.authorName)} · ${formatDateTime(item.createdAt)}</small>
            </article>
        `).join("") || `<div class="empty-state">暂无公告</div>`;
}

function renderAdminAnnouncements() {
    const container = document.getElementById("admin-announcement-list");
    container.innerHTML = state.announcements.length
        ? state.announcements.map(item => `
            <article class="admin-announcement-item">
                <strong>${escapeHtml(item.title)}</strong>
                <p>${escapeHtml(item.content)}</p>
                <small>${escapeHtml(item.authorName)} · ${formatDateTime(item.createdAt)}</small>
            </article>
        `).join("")
        : `<div class="empty-state">暂无公告</div>`;
}

function renderVenues() {
    const select = document.getElementById("reservation-venue");
    const previous = select.value;
    select.innerHTML = state.venues.map(venue =>
        `<option value="${venue.id}">${escapeHtml(venue.name)} · ${escapeHtml(venue.campusZone)}</option>`
    ).join("");
    if (previous && state.venues.some(venue => String(venue.id) === previous)) {
        select.value = previous;
    }

    document.getElementById("venue-list").innerHTML = state.venues.length
        ? state.venues.map(venue => `
            <article class="venue-item">
                <strong>${escapeHtml(venue.name)}</strong>
                <p>${escapeHtml(venue.address)}</p>
                <small>${venue.openTime.slice(0, 5)} - ${venue.closeTime.slice(0, 5)} · ${venue.indoor ? "室内" : "室外"}</small>
            </article>
        `).join("")
        : `<div class="empty-state">暂无可用场地</div>`;

    loadBusySlots();
}

function renderReservations() {
    const container = document.getElementById("reservation-list");
    if (!state.reservations.length) {
        container.innerHTML = `<div class="empty-state">还没有场地预约</div>`;
        return;
    }
    container.innerHTML = state.reservations.map(reservation => `
        <article class="reservation-item ${reservation.status === "CANCELLED" ? "cancelled" : ""}">
            <div>
                <strong>${escapeHtml(reservation.venueName)}</strong>
                <p>${reservation.reservationDate} · ${reservation.startTime.slice(0, 5)} - ${reservation.endTime.slice(0, 5)}</p>
                <p>${reservation.status === "CONFIRMED" ? "已确认" : statusLabels[reservation.status]}</p>
            </div>
            ${reservation.status === "CONFIRMED"
                ? `<button class="btn btn-danger btn-small" data-action="cancel-reservation" data-id="${reservation.id}">取消</button>`
                : ""}
        </article>
    `).join("");
}

function renderRealtime() {
    if (!state.realtimeStatus) {
        return;
    }
    const current = state.realtimeStatus.current || { status: "NONE" };
    document.getElementById("live-match-stats").innerHTML = `
        <span><i></i>在线 <strong>${state.realtimeStatus.onlineUsers}</strong></span>
        <span>搜索中 <strong>${state.realtimeStatus.searchingUsers}</strong></span>
    `;

    const sportInput = document.getElementById("realtime-sport");
    if (!sportInput.dataset.initialized) {
        sportInput.value = state.user.sportPreferences[0] || "";
        document.getElementById("realtime-zone").value = state.user.campusZone || "东区";
        document.getElementById("realtime-skill").value = state.user.skillLevel || "BEGINNER";
        document.getElementById("realtime-latitude").value = state.user.latitude;
        document.getElementById("realtime-longitude").value = state.user.longitude;
        sportInput.dataset.initialized = "true";
    }

    const stage = document.getElementById("realtime-stage");
    if (current.status === "SEARCHING") {
        stage.innerHTML = `
            <div class="realtime-searching">
                <div class="search-radar-shell">
                    <span class="radar-pulse pulse-one"></span>
                    <span class="radar-pulse pulse-two"></span>
                    <span class="radar-pulse pulse-three"></span>
                    <div class="search-radar">
                        <span class="radar-ring ring-one"></span>
                        <span class="radar-ring ring-two"></span>
                        <span class="radar-axis axis-x"></span>
                        <span class="radar-axis axis-y"></span>
                        <span class="radar-sweep"></span>
                        <span class="radar-blip blip-one"></span>
                        <span class="radar-blip blip-two"></span>
                        <span class="radar-blip blip-three"></span>
                        <i></i>
                    </div>
                </div>
                <h3>正在实时寻找搭子</h3>
                <p>系统正在扫描在线学生。有人发起相同运动与时间窗时，会立即完成撮合并通知双方。</p>
                <div class="search-live-row">
                    <span><i class="search-live-dot"></i>WebSocket 实时扫描中</span>
                    <strong id="search-waiting-time">已扫描 00:00</strong>
                </div>
                <div class="search-criteria">
                    <span>${escapeHtml(current.sportType)}</span>
                    <span>${matchTimeLabels[current.timeWindow] || current.timeWindow}</span>
                    <span>${escapeHtml(state.user.campusZone)}</span>
                    <span>${skillLabels[state.user.skillLevel]}</span>
                </div>
                <div class="search-scan-line"><i></i></div>
                <button class="btn btn-ghost btn-small" data-action="cancel-realtime" style="margin-top:22px">取消匹配</button>
            </div>`;
        return;
    }

    if (current.status === "MATCHED" && current.partner) {
        const partner = current.partner;
        const breakdown = current.scoreBreakdown || {};
        stage.innerHTML = `
            <div class="matched-state">
                <span class="eyebrow">MATCH FOUND</span>
                <h3>找到合拍的运动搭子</h3>
                <p>双方已收到实时通知，可以约一场说走就走的运动。</p>
                <div class="partner-card">
                    <div class="partner-avatar">${escapeHtml(partner.displayName.slice(0, 1))}</div>
                    <div>
                        <h4>${escapeHtml(partner.displayName)}</h4>
                        <p>${skillLabels[partner.skillLevel]} · ${escapeHtml(partner.campusZone)} · 信用 ${partner.creditScore}</p>
                        <p>偏好：${partner.sportPreferences.map(escapeHtml).join(" / ") || "暂无"} · 距离 ${partner.distanceKm}km</p>
                    </div>
                    <div class="partner-score">
                        <strong>${current.matchScore}</strong>
                        <small>综合匹配分</small>
                    </div>
                </div>
                <div class="match-breakdown">
                    <div><strong>${breakdown.sport || 0}</strong><span>运动项目</span></div>
                    <div><strong>${breakdown.time || 0}</strong><span>时间窗</span></div>
                    <div><strong>${breakdown.distance || 0}</strong><span>距离</span></div>
                    <div><strong>${breakdown.skill || 0}</strong><span>水平</span></div>
                    <div><strong>${breakdown.credit || 0}</strong><span>信用</span></div>
                </div>
                <div class="match-highlights">
                    ${(current.highlights || []).map(item => `<span>${escapeHtml(item)}</span>`).join("")}
                </div>
                <div class="matched-actions">
                    <button class="btn btn-light" data-action="realtime-rematch">重新匹配</button>
                    <button class="btn btn-danger" data-action="cancel-realtime">结束本次匹配</button>
                </div>
            </div>`;
        return;
    }

    stage.innerHTML = `
        <div class="realtime-idle">
            <div class="radar-mini"><i></i><span></span></div>
            <h3>准备进入匹配池</h3>
            <p>选择运动项目和时间窗，系统会在在线学生中实时计算最佳搭子。</p>
        </div>`;
}

function applyRealtimeTick(data) {
    if (!state.realtimeStatus || !data) {
        return;
    }
    if (Number.isFinite(data.onlineUsers)) {
        state.realtimeStatus.onlineUsers = data.onlineUsers;
    }
    if (Number.isFinite(data.searchingUsers)) {
        state.realtimeStatus.searchingUsers = data.searchingUsers;
    }
    const stats = document.getElementById("live-match-stats");
    if (stats) {
        stats.innerHTML = `
            <span><i></i>在线 <strong>${state.realtimeStatus.onlineUsers}</strong></span>
            <span>搜索中 <strong>${state.realtimeStatus.searchingUsers}</strong></span>
        `;
    }
    const timer = document.getElementById("search-waiting-time");
    if (timer && Number.isFinite(data.waitingSeconds)) {
        const minutes = String(Math.floor(data.waitingSeconds / 60)).padStart(2, "0");
        const seconds = String(data.waitingSeconds % 60).padStart(2, "0");
        timer.textContent = `已扫描 ${minutes}:${seconds}`;
    }
}

function renderProfile() {
    if (!state.user) {
        return;
    }
    document.getElementById("profile-name").value = state.user.displayName;
    document.getElementById("profile-username").value = state.user.username;
    document.getElementById("profile-skill").value = state.user.skillLevel;
    document.getElementById("profile-zone").value = state.user.campusZone;
    document.getElementById("profile-sports").value = state.user.sportPreferences.join(",");
    document.getElementById("profile-slots").value = state.user.availableTimeSlots.join(",");
    document.getElementById("profile-latitude").value = state.user.latitude;
    document.getElementById("profile-longitude").value = state.user.longitude;
}

function renderPending() {
    const container = document.getElementById("pending-list");
    if (!container) {
        return;
    }
    if (!state.pending.length) {
        container.innerHTML = `<div class="empty-state">当前没有待审核活动</div>`;
        return;
    }
    container.innerHTML = state.pending.map(activity => `
        <article class="review-card">
            <div class="card-top">
                <span class="sport-chip">${escapeHtml(activity.sportType)}</span>
                <span class="status-chip pending">待审核</span>
            </div>
            <h3>${escapeHtml(activity.title)}</h3>
            <p>${escapeHtml(activity.description || "无活动说明")}</p>
            <div class="review-meta">
                <span>${formatDateTime(activity.startTime)}</span>
                <span>${escapeHtml(activity.locationName)}</span>
                <span>${escapeHtml(activity.creatorName)}</span>
                <span>${activity.maxParticipants} 人</span>
                <span>信用 ${activity.minCreditScore}+</span>
            </div>
            <div class="card-actions">
                <button class="btn btn-danger btn-small" data-action="reject-activity" data-id="${activity.id}">驳回</button>
                <button class="btn btn-primary btn-small" data-action="approve-activity" data-id="${activity.id}">通过审核</button>
            </div>
        </article>
    `).join("");
}

function renderUsers() {
    const tbody = document.getElementById("user-table");
    if (!tbody) {
        return;
    }
    tbody.innerHTML = state.users.map(user => `
        <tr>
            <td><strong>${escapeHtml(user.displayName)}</strong><small>@${escapeHtml(user.username)} · ${escapeHtml(user.campusZone)}</small></td>
            <td>${user.sportPreferences.map(escapeHtml).join(" / ")}</td>
            <td>${skillLabels[user.skillLevel]}</td>
            <td><span class="credit-value">${user.creditScore}</span></td>
            <td><span class="account-status ${user.enabled ? "" : "disabled"}">${user.enabled ? "正常" : "已禁用"}</span></td>
            <td>
                <div class="table-actions">
                    <button class="btn btn-outline btn-small" data-action="adjust-credit" data-id="${user.id}">调整分</button>
                    <button class="btn ${user.enabled ? "btn-danger" : "btn-primary"} btn-small" data-action="toggle-user" data-id="${user.id}" data-enabled="${user.enabled}">
                        ${user.enabled ? "禁用" : "启用"}
                    </button>
                </div>
            </td>
        </tr>
    `).join("") || `<tr><td colspan="6">暂无学生用户</td></tr>`;
}

async function handleActionClick(event) {
    const button = event.target.closest("[data-action]");
    if (!button) {
        return;
    }
    const action = button.dataset.action;
    const id = Number(button.dataset.id);

    try {
        if (action === "open-create") {
            openModal("activity-modal");
        } else if (action === "close-modal") {
            button.closest(".modal-backdrop").classList.add("hidden");
        } else if (action === "join") {
            await api(`/api/activities/${id}/join`, { method: "POST" });
            toast("已成功加入活动");
            await refreshActivityData();
        } else if (action === "leave") {
            if (!window.confirm("确定退出该活动吗？")) {
                return;
            }
            await api(`/api/activities/${id}/join`, { method: "DELETE" });
            toast("已退出活动");
            await refreshActivityData();
        } else if (action === "match") {
            await openMatches(id);
        } else if (action === "invite") {
            const userId = Number(button.dataset.userId);
            await api(`/api/activities/${state.currentMatchActivityId}/invite/${userId}`, { method: "POST" });
            toast("邀请通知已发送");
        } else if (action === "approve-activity") {
            await api(`/api/admin/activities/${id}/review`, {
                method: "PATCH",
                body: JSON.stringify({ approved: true })
            });
            toast("活动已通过审核");
            await refreshAdminData();
            await refreshActivityData();
        } else if (action === "reject-activity") {
            const reason = window.prompt("请输入驳回原因：");
            if (!reason) {
                return;
            }
            await api(`/api/admin/activities/${id}/review`, {
                method: "PATCH",
                body: JSON.stringify({ approved: false, reason })
            });
            toast("活动已驳回");
            await refreshAdminData();
        } else if (action === "adjust-credit") {
            const user = state.users.find(item => item.id === id);
            const value = window.prompt(`输入 ${user.displayName} 的新信用分（0-100）：`, user.creditScore);
            if (value === null) {
                return;
            }
            await api(`/api/admin/users/${id}`, {
                method: "PATCH",
                body: JSON.stringify({ creditScore: Number(value) })
            });
            toast("信用分已更新");
            await refreshAdminData();
        } else if (action === "toggle-user") {
            const enabled = button.dataset.enabled === "true";
            await api(`/api/admin/users/${id}`, {
                method: "PATCH",
                body: JSON.stringify({ enabled: !enabled })
            });
            toast(enabled ? "账户已禁用" : "账户已启用");
            await refreshAdminData();
        } else if (action === "cancel-reservation") {
            if (!window.confirm("确定取消该场地预约吗？")) {
                return;
            }
            await api(`/api/reservations/${id}`, { method: "DELETE" });
            toast("预约已取消");
            state.reservations = await api("/api/reservations/mine");
            renderReservations();
            await loadBusySlots();
        } else if (action === "cancel-realtime") {
            await api("/api/realtime/matches/current", { method: "DELETE" });
            await loadRealtimeStatus();
            toast("已退出实时匹配");
        } else if (action === "realtime-rematch") {
            document.getElementById("realtime-match-form").requestSubmit();
        } else if (action === "radar-lock") {
            const candidateId = Number(button.dataset.userId);
            if (!state.radarSession) {
                return;
            }
            state.radarSession = await api(
                `/api/radar/sessions/${state.radarSession.sessionId}/candidates/${candidateId}/lock`,
                { method: "POST" }
            );
            renderRadar();
            toast("候选已锁定，雷达扫描暂停");
        } else if (action === "radar-engage") {
            if (!state.radarSession || !state.radarSession.selectedCandidateId) {
                return;
            }
            const candidateId = state.radarSession.selectedCandidateId;
            const result = await api(
                `/api/radar/sessions/${state.radarSession.sessionId}/candidates/${candidateId}/engage`,
                { method: "POST" }
            );
            state.radarReceipt = result;
            state.radarSession = null;
            renderRadar();
            toast(result.message);
        } else if (action === "radar-resume") {
            if (!state.radarSession) {
                return;
            }
            state.radarSession = await api(
                `/api/radar/sessions/${state.radarSession.sessionId}/resume`,
                { method: "POST" }
            );
            renderRadar();
            toast("雷达扫描已恢复");
        } else if (action === "radar-simulate") {
            if (!state.radarSession) {
                return;
            }
            state.radarSession = await api(
                `/api/radar/sessions/${state.radarSession.sessionId}/simulate-event`,
                { method: "POST" }
            );
            renderRadar();
            toast(state.radarSession.lastEvent);
        } else if (action === "radar-close") {
            if (!state.radarSession) {
                return;
            }
            await api(`/api/radar/sessions/${state.radarSession.sessionId}`, { method: "DELETE" });
            state.radarSession = null;
            renderRadar();
            toast("雷达会话已关闭");
        }
    } catch (error) {
        toast(error.message, true);
    }
}

async function startRealtimeMatch(event) {
    event.preventDefault();
    const payload = {
        sportType: document.getElementById("realtime-sport").value.trim(),
        timeWindow: document.getElementById("realtime-time").value,
        campusZone: document.getElementById("realtime-zone").value.trim(),
        skillLevel: document.getElementById("realtime-skill").value,
        latitude: Number(document.getElementById("realtime-latitude").value),
        longitude: Number(document.getElementById("realtime-longitude").value)
    };
    try {
        const result = await api("/api/realtime/matches", {
            method: "POST",
            body: JSON.stringify(payload)
        });
        state.realtimeStatus = {
            ...(state.realtimeStatus || { onlineUsers: 1, searchingUsers: 0 }),
            current: result
        };
        renderRealtime();
        await loadRealtimeStatus();
    } catch (error) {
        toast(error.message, true);
    }
}

async function loadRealtimeStatus() {
    if (state.user?.role !== "STUDENT") {
        return;
    }
    state.realtimeStatus = await api("/api/realtime/status");
    renderRealtime();
}

async function startRadarSession(event) {
    event.preventDefault();
    state.radarReceipt = null;
    const payload = {
        sportType: document.getElementById("radar-sport").value.trim(),
        timeWindow: document.getElementById("radar-time").value,
        skillLevel: document.getElementById("radar-skill").value,
        latitude: Number(document.getElementById("radar-latitude").value),
        longitude: Number(document.getElementById("radar-longitude").value),
        radiusKm: Number(document.getElementById("radar-radius").value),
        topN: Number(document.getElementById("radar-top-n").value),
        simulationMode: document.getElementById("radar-simulation").checked
    };
    try {
        state.radarSession = await api("/api/radar/sessions", {
            method: "POST",
            body: JSON.stringify(payload)
        });
        renderRadar();
        toast("雷达已启动，正在扫描 8 个扇区");
    } catch (error) {
        toast(error.message, true);
    }
}

async function loadCurrentRadar() {
    try {
        state.radarSession = await api("/api/radar/sessions/current");
        renderRadar();
    } catch (error) {
        if (error.status !== 404) {
            toast(error.message, true);
        }
    }
}

function renderRadar() {
    const summary = document.getElementById("radar-summary");
    const board = document.getElementById("radar-board");
    const stateTitle = document.getElementById("radar-state-title");
    const stateChip = document.getElementById("radar-state-chip");
    const actionContainer = document.getElementById("radar-actions");
    const list = document.getElementById("radar-candidate-list");
    const eventTitle = document.getElementById("radar-event-title");
    const eventText = document.getElementById("radar-event-text");
    if (!summary || !board) {
        return;
    }

    const session = state.radarSession;
    if (!session) {
        summary.innerHTML = `
            <span>状态 <strong>待启动</strong></span>
            <span>扇区 <strong>0/8</strong></span>
            <span>候选 <strong>0</strong></span>`;
        stateTitle.textContent = state.radarReceipt ? "组队邀约已发送" : "雷达待启动";
        stateChip.className = "radar-state-chip";
        stateChip.textContent = state.radarReceipt ? state.radarReceipt.status : "IDLE";
        board.className = "radar-board";
        board.innerHTML = `
            <div class="radar-empty">
                <div class="radar-idle-ring"></div>
                <strong>${state.radarReceipt ? "雷达已完成匹配" : "等待启动雷达"}</strong>
                <span>${state.radarReceipt ? "组队邀约已经写入数据库" : "设置条件后开始实时扫描"}</span>
            </div>`;
        actionContainer.innerHTML = "";
        list.innerHTML = state.radarReceipt
            ? `<div class="empty-state">已向 ${escapeHtml(state.radarReceipt.candidateName)} 发起邀约，匹配分 ${state.radarReceipt.matchScore}，等待对方确认。</div>`
            : `<div class="empty-state">启动雷达后展示 Top-N 候选</div>`;
        eventTitle.textContent = state.radarReceipt ? "邀约记录已创建" : "暂无事件";
        eventText.textContent = state.radarReceipt
            ? `邀约编号 #${state.radarReceipt.matchId} · ${state.radarReceipt.sportType} · 状态 ${state.radarReceipt.status}`
            : "服务端扫描、Top-N 变化和候选补位会显示在这里。";
        return;
    }

    const running = session.state === "RUNNING";
    summary.innerHTML = `
        <span>状态 <strong>${running ? "扫描中" : session.state === "PAUSED" ? "已暂停" : session.state}</strong></span>
        <span>扇区 <strong>${session.currentSector + 1}/${session.sectors}</strong></span>
        <span>候选 <strong>${session.blips.length}</strong></span>`;
    stateTitle.textContent = running ? "雷达正在扫描" : "候选已锁定";
    stateChip.textContent = session.state;
    stateChip.className = `radar-state-chip ${session.state.toLowerCase()}`;
    board.className = `radar-board ${running ? "" : "paused"}`;

    const rings = [82, 62, 42, 22].map(size => `
        <span class="radar-ring" style="width:${size}%;height:${size}%"></span>
    `).join("");
    const sectorLines = [0, 45, 90, 135].map(angle => `
        <span class="radar-sector-line" style="transform:rotate(${angle}deg)"></span>
    `).join("");
    const blips = session.blips.map((blip, index) => {
        const angle = (blip.angle || 0) * Math.PI / 180;
        const radius = 8 + Math.min(1, blip.radiusRatio || 0) * 38;
        const left = 50 + Math.sin(angle) * radius;
        const top = 50 - Math.cos(angle) * radius;
        const selected = blip.userId === session.selectedCandidateId;
        return `
            <button class="radar-blip ${selected ? "selected" : ""}"
                    style="left:${left}%;top:${top}%;animation-delay:${index * .23}s"
                    data-action="radar-lock" data-user-id="${blip.userId}"
                    title="${escapeHtml(blip.displayName)} · ${blip.score}分">
                ${index + 1}
                <span class="blip-score">${blip.score}</span>
            </button>`;
    }).join("");
    board.innerHTML = `
        ${rings}
        ${sectorLines}
        <span class="radar-direction north">北</span>
        <span class="radar-direction east">东</span>
        <span class="radar-direction south">南</span>
        <span class="radar-direction west">西</span>
        <span class="radar-sweep"></span>
        <span class="radar-center"></span>
        ${blips}`;

    const selected = session.blips.find(blip => blip.userId === session.selectedCandidateId);
    const actionButtons = [];
    if (running) {
        actionButtons.push(`<button class="btn btn-outline btn-small" data-action="radar-simulate">模拟候选下线</button>`);
    }
    if (session.state === "PAUSED" && selected) {
        actionButtons.push(`<button class="btn btn-primary btn-small" data-action="radar-engage">向 ${escapeHtml(selected.displayName)} 发起组队</button>`);
        actionButtons.push(`<button class="btn btn-ghost btn-small" data-action="radar-resume">继续扫描</button>`);
    }
    actionButtons.push(`<button class="btn btn-ghost btn-small" data-action="radar-close">关闭雷达</button>`);
    actionContainer.innerHTML = actionButtons.join("");

    list.innerHTML = session.blips.length
        ? session.blips.map((blip, index) => {
            const selectedClass = blip.userId === session.selectedCandidateId ? "selected" : "";
            const action = blip.userId === session.selectedCandidateId && session.state === "PAUSED"
                ? `<button class="btn btn-primary btn-small" data-action="radar-engage">发起组队</button>`
                : `<button class="btn btn-outline btn-small" data-action="radar-lock" data-user-id="${blip.userId}">锁定</button>`;
            return `
                <article class="radar-candidate ${selectedClass}">
                    <div class="radar-rank">${index + 1}</div>
                    <div>
                        <strong>${escapeHtml(blip.displayName)}</strong>
                        <p>${skillLabels[blip.skillLevel]} · ${escapeHtml(blip.campusZone)} · ${blip.distanceKm}km · 信用 ${blip.creditScore}</p>
                        <p>${blip.highlights.map(escapeHtml).join(" · ") || "可进一步了解"}</p>
                    </div>
                    <div class="radar-candidate-score">${blip.score}<small>匹配分</small></div>
                    ${action}
                </article>`;
        }).join("")
        : `<div class="empty-state">当前半径内没有符合条件的候选，调整距离或运动项目后重试。</div>`;

    eventTitle.textContent = session.lastEvent === "TOP_N_UPDATED"
        ? "Top-N 已更新"
        : session.lastEvent === "RADAR_LOCKED"
            ? "候选已锁定"
            : session.lastEvent === "SECTOR_SWEEP"
                ? `正在扫描扇区 ${session.currentSector + 1}`
                : session.lastEvent;
    eventText.textContent = `版本 ${session.version} · 已扫描 ${session.scannedSectors}/${session.sectors} 个扇区 · 在线候选 ${session.onlineCandidates} · 更新时间 ${formatDateTime(session.updatedAt)}`;
}

function handleRadarEvent(payload) {
    if (payload.type === "RADAR_INVITATION" || payload.type === "RADAR_MATCH_ACCEPTED" || payload.type === "RADAR_MATCH_REJECTED") {
        toast(payload.message);
        return;
    }
    const session = payload.data;
    if (!session || !session.sessionId) {
        return;
    }
    if (payload.type === "RADAR_CLOSED") {
        state.radarSession = null;
        renderRadar();
        toast(payload.message);
        return;
    }
    if (!state.radarSession || state.radarSession.sessionId === session.sessionId) {
        state.radarSession = session;
        renderRadar();
    }
    if (payload.type === "RADAR_EVENT") {
        toast(payload.message);
    }
}

async function login(event) {
    event.preventDefault();
    const username = document.getElementById("login-username").value.trim();
    const password = document.getElementById("login-password").value;
    try {
        const response = await api("/api/auth/login", {
            method: "POST",
            body: JSON.stringify({ username, password })
        });
        state.token = response.token;
        state.user = response.user;
        localStorage.setItem("sportsBuddyToken", state.token);
        toast(`欢迎回来，${response.user.displayName}`);
        await openApp();
        showView(response.user.role === "ADMIN" ? "admin-review" : "discover");
    } catch (error) {
        toast(error.message, true);
    }
}

async function register(event) {
    event.preventDefault();
    const payload = {
        username: document.getElementById("reg-username").value.trim(),
        password: document.getElementById("reg-password").value,
        displayName: document.getElementById("reg-display-name").value.trim(),
        sportPreferences: splitValues(document.getElementById("reg-sports").value),
        skillLevel: document.getElementById("reg-skill").value,
        campusZone: document.getElementById("reg-zone").value.trim(),
        availableTimeSlots: splitValues(document.getElementById("reg-slots").value),
        latitude: 31.2304,
        longitude: 121.4737
    };
    try {
        const response = await api("/api/auth/register", {
            method: "POST",
            body: JSON.stringify(payload)
        });
        state.token = response.token;
        state.user = response.user;
        localStorage.setItem("sportsBuddyToken", state.token);
        toast("注册成功，开始寻找运动搭子吧");
        await openApp();
        showView("discover");
    } catch (error) {
        toast(error.message, true);
    }
}

async function createActivity(event) {
    event.preventDefault();
    const payload = {
        title: document.getElementById("activity-title").value.trim(),
        sportType: document.getElementById("activity-sport").value.trim(),
        description: document.getElementById("activity-description").value.trim(),
        campusZone: document.getElementById("activity-zone").value.trim(),
        locationName: document.getElementById("activity-location").value.trim(),
        startTime: document.getElementById("activity-start").value,
        endTime: document.getElementById("activity-end").value,
        maxParticipants: Number(document.getElementById("activity-max").value),
        requiredSkillLevel: document.getElementById("activity-skill").value,
        minCreditScore: Number(document.getElementById("activity-credit").value),
        latitude: Number(document.getElementById("activity-latitude").value),
        longitude: Number(document.getElementById("activity-longitude").value)
    };
    try {
        await api("/api/activities", {
            method: "POST",
            body: JSON.stringify(payload)
        });
        document.getElementById("activity-modal").classList.add("hidden");
        document.getElementById("activity-form").reset();
        setDefaultDates();
        toast("活动已提交，等待管理员审核");
        await refreshActivityData();
        showView("mine");
    } catch (error) {
        toast(error.message, true);
    }
}

async function openMatches(activityId) {
    state.currentMatchActivityId = activityId;
    const activity = [...state.activities, ...state.mine].find(item => item.id === activityId);
    document.getElementById("match-title").textContent = activity
        ? `${activity.title} · 推荐搭子`
        : "智能搭子推荐";
    document.getElementById("match-list").innerHTML = `<div class="empty-state">正在计算匹配分...</div>`;
    openModal("match-modal");

    try {
        const matches = await api(`/api/activities/${activityId}/matches?limit=10`);
        const container = document.getElementById("match-list");
        container.innerHTML = matches.length
            ? matches.map((match, index) => `
                <article class="match-item">
                    <span class="match-rank">${index + 1}</span>
                    <div class="match-person">
                        <strong>${escapeHtml(match.displayName)}
                            <small>${skillLabels[match.skillLevel]} · ${escapeHtml(match.campusZone)} · ${match.distanceKm}km</small>
                        </strong>
                        <p>${match.highlights.map(escapeHtml).join(" · ") || "可进一步了解"}</p>
                        <div class="match-bar"><i style="width:${match.matchScore}%"></i></div>
                    </div>
                    <div class="match-score">
                        <strong>${match.matchScore}</strong><small> 匹配分</small>
                    </div>
                    <button class="btn btn-outline btn-small" data-action="invite" data-user-id="${match.userId}">邀请</button>
                </article>
            `).join("")
            : `<div class="empty-state">暂未找到符合条件的候选人</div>`;
    } catch (error) {
        document.getElementById("match-list").innerHTML =
            `<div class="empty-state">${escapeHtml(error.message)}</div>`;
    }
}

async function createReservation(event) {
    event.preventDefault();
    const payload = {
        venueId: Number(document.getElementById("reservation-venue").value),
        reservationDate: document.getElementById("reservation-date").value,
        startTime: document.getElementById("reservation-start").value,
        endTime: document.getElementById("reservation-end").value
    };
    try {
        await api("/api/reservations", {
            method: "POST",
            body: JSON.stringify(payload)
        });
        toast("场地预约成功");
        state.reservations = await api("/api/reservations/mine");
        renderReservations();
        await loadBusySlots();
    } catch (error) {
        toast(error.message, true);
    }
}

async function loadBusySlots() {
    const venueId = document.getElementById("reservation-venue").value;
    const date = document.getElementById("reservation-date").value;
    const container = document.getElementById("busy-slots");
    if (!venueId || !date) {
        container.innerHTML = "<span>选择场地和日期后查看</span>";
        return;
    }
    try {
        const slots = await api(`/api/venues/${venueId}/busy?date=${encodeURIComponent(date)}`);
        container.innerHTML = slots.length
            ? slots.map(slot => `<span class="busy">${slot.startTime.slice(0, 5)} - ${slot.endTime.slice(0, 5)} 已占用</span>`).join("")
            : "<span>当前日期暂无占用，可预约</span>";
    } catch (error) {
        container.innerHTML = `<span>${escapeHtml(error.message)}</span>`;
    }
}

async function saveProfile(event) {
    event.preventDefault();
    const payload = {
        displayName: document.getElementById("profile-name").value.trim(),
        sportPreferences: splitValues(document.getElementById("profile-sports").value),
        skillLevel: document.getElementById("profile-skill").value,
        campusZone: document.getElementById("profile-zone").value.trim(),
        availableTimeSlots: splitValues(document.getElementById("profile-slots").value),
        latitude: Number(document.getElementById("profile-latitude").value),
        longitude: Number(document.getElementById("profile-longitude").value)
    };
    try {
        state.user = await api("/api/me", {
            method: "PUT",
            body: JSON.stringify(payload)
        });
        applyUserChrome();
        renderProfile();
        toast("个人档案已保存，匹配结果将随之更新");
    } catch (error) {
        toast(error.message, true);
    }
}

async function publishAnnouncement(event) {
    event.preventDefault();
    const payload = {
        title: document.getElementById("announcement-title").value.trim(),
        content: document.getElementById("announcement-content").value.trim()
    };
    try {
        await api("/api/admin/announcements", {
            method: "POST",
            body: JSON.stringify(payload)
        });
        event.target.reset();
        state.announcements = await api("/api/announcements");
        renderAnnouncements();
        renderAdminAnnouncements();
        toast("公告已发布并实时推送");
    } catch (error) {
        toast(error.message, true);
    }
}

function connectSocket() {
    if (state.socket) {
        state.socket.onclose = null;
        state.socket.close();
    }
    if (!state.token) {
        return;
    }
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const socket = new WebSocket(
        `${protocol}//${window.location.host}/ws/notifications?token=${encodeURIComponent(state.token)}`
    );
    state.socket = socket;

    socket.onopen = () => {
        clearInterval(state.heartbeatTimer);
        state.heartbeatTimer = setInterval(() => {
            if (state.socket?.readyState === WebSocket.OPEN) {
                state.socket.send(JSON.stringify({ type: "PING" }));
            }
        }, 25000);
    };

    socket.onmessage = event => {
        try {
            const payload = JSON.parse(event.data);
            if (payload.type === "PONG") {
                return;
            }
            if (payload.type === "REALTIME_SEARCH_TICK") {
                applyRealtimeTick(payload.data);
                return;
            }
            if (payload.type.startsWith("RADAR_")) {
                handleRadarEvent(payload);
                return;
            }
            toast(payload.message || "收到一条新通知");
            if (payload.type.startsWith("REALTIME_")) {
                loadRealtimeStatus().catch(error => toast(error.message, true));
            } else if (payload.type !== "ACTIVITY_INVITATION") {
                scheduleRefresh();
            }
        } catch (error) {
            console.warn("无法解析 WebSocket 通知", error);
        }
    };

    socket.onclose = () => {
        clearInterval(state.heartbeatTimer);
        if (!state.token) {
            return;
        }
        clearTimeout(state.socketTimer);
        state.socketTimer = setTimeout(connectSocket, 3000);
    };
}

function scheduleRefresh() {
    clearTimeout(state.refreshTimer);
    state.refreshTimer = setTimeout(() => refreshAll(), 500);
}

async function refreshActivityData() {
    const [activities, mine] = await Promise.all([
        api("/api/activities"),
        api("/api/activities/mine")
    ]);
    state.activities = activities;
    state.mine = mine;
    renderActivities(state.activities, "activity-grid");
    renderActivities(state.mine, "mine-grid");
}

async function refreshAdminData() {
    const [pending, users] = await Promise.all([
        api("/api/admin/activities/pending"),
        api("/api/admin/users")
    ]);
    state.pending = pending;
    state.users = users;
    renderPending();
    renderUsers();
    document.getElementById("pending-badge").textContent = pending.length;
}

async function loadActivities() {
    state.activities = await api("/api/activities");
}

function showView(view) {
    if (view.startsWith("admin-") && state.user.role !== "ADMIN") {
        return;
    }
    document.querySelectorAll(".view").forEach(section => section.classList.remove("active"));
    document.querySelectorAll(".nav-item").forEach(button => {
        button.classList.toggle("active", button.dataset.view === view);
    });
    document.getElementById(`view-${view}`).classList.add("active");
    const [eyebrow, title, subtitle] = viewMeta[view];
    document.getElementById("view-eyebrow").textContent = eyebrow;
    document.getElementById("view-title").textContent = title;
    document.getElementById("view-subtitle").textContent = subtitle;
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (view === "venues") {
        loadBusySlots();
    } else if (view === "realtime") {
        loadRealtimeStatus().catch(error => toast(error.message, true));
    } else if (view === "radar") {
        loadCurrentRadar();
    }
}

function switchAuthTab(tab) {
    document.querySelectorAll("[data-auth-tab]").forEach(button => {
        button.classList.toggle("active", button.dataset.authTab === tab);
    });
    document.getElementById("login-form").classList.toggle("hidden", tab !== "login");
    document.getElementById("register-form").classList.toggle("hidden", tab !== "register");
}

function openModal(id) {
    document.getElementById(id).classList.remove("hidden");
}

function logout() {
    clearSession(true);
    showAuth();
    switchAuthTab("login");
}

function clearSession(notify) {
    if (state.socket) {
        state.socket.onclose = null;
        state.socket.close();
    }
    state.token = null;
    state.user = null;
    state.socket = null;
    localStorage.removeItem("sportsBuddyToken");
    clearTimeout(state.socketTimer);
    clearTimeout(state.refreshTimer);
    clearInterval(state.heartbeatTimer);
    if (notify) {
        toast("登录状态已失效，请重新登录", true);
    }
}

function toast(message, isError = false) {
    const stack = document.getElementById("toast-stack");
    const element = document.createElement("div");
    element.className = `toast ${isError ? "error" : ""}`;
    element.innerHTML = `<span class="toast-dot"></span><span>${escapeHtml(message)}</span>`;
    stack.appendChild(element);
    setTimeout(() => {
        element.style.opacity = "0";
        element.style.transform = "translateX(14px)";
        setTimeout(() => element.remove(), 250);
    }, 4200);
}

function setDefaultDates() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    document.getElementById("reservation-date").value = localDate(tomorrow);

    const start = new Date(tomorrow);
    start.setHours(19, 30, 0, 0);
    const end = new Date(start);
    end.setHours(20, 30, 0, 0);
    document.getElementById("activity-start").value = localDateTime(start);
    document.getElementById("activity-end").value = localDateTime(end);
}

function localDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function localDateTime(date) {
    const hour = String(date.getHours()).padStart(2, "0");
    const minute = String(date.getMinutes()).padStart(2, "0");
    return `${localDate(date)}T${hour}:${minute}`;
}

function formatDateTime(value) {
    if (!value) {
        return "";
    }
    return new Intl.DateTimeFormat("zh-CN", {
        month: "numeric",
        day: "numeric",
        weekday: "short",
        hour: "2-digit",
        minute: "2-digit"
    }).format(new Date(value));
}

function splitValues(value) {
    return value.split(/[,，]/).map(item => item.trim()).filter(Boolean);
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
